﻿ECRA optimize_cc -> optimize_ccc 离线打包缓存增量

适用前提：目标电脑已有 optimize_cc 能成功打包的完整 .tools-cache。
本包只补新增环境，不包含原有 Python、编译工具链、libclang 与 PyYAML。
目标电脑可以完全断网。使用 Windows x64 自带的 Windows PowerShell 5.1。

一、两个分支之间真正的环境差异

1. 必需新增：17 个 Windows/Python 3.10 兼容 wheel 及各自 .receipt.json。
   ruamel.yaml 0.18.16、ruamel.yaml.clib 0.2.12、fastapi 0.136.3、uvicorn 0.49.0、
   pydantic 2.13.4、pydantic-core 2.46.4、starlette 1.2.1、typing-extensions 4.15.0、
   typing-inspection 0.4.2、annotated-types 0.7.0、annotated-doc 0.0.4、anyio 4.13.0、
   idna 3.18、exceptiongroup 1.3.1、click 8.4.1、colorama 0.4.6、h11 0.16.0。
   wheel 文件合计 3,500,925 字节；收据记录发布来源与 SHA256，必须一起带走。

2. Git 差异功能需要：完整 MinGit 2.56.0.windows.3 分发目录。
   本增量已包含它，不需要在目标机安装系统 Git，也不能只复制 git.exe。
   新版打包脚本只有传 -GitSource 才会把它装进用户包。

3. 沿用旧缓存，版本未改变：
   Python 3.10.9 / CMake 3.29.6 / Ninja 1.13.2 / MinGW GCC 14.2.0 / Make 4.4.1 /
   Arm GCC 10.3.1 / VC runtime 14.44.35211.0 / pip 25.2 / libclang 18.1.1 / PyYAML 6.0.3。
   config/portable_sources.psd1 和 requirements.txt 在两个分支之间内容相同。

4. 前端成品 ecra/studio/web/、许可证、教学归档已随 Git 跟踪。
   直接使用当前提交打包，不需要 Node、npm、studio/node_modules 或系统 Python。
   本包不提供修改前端后重新执行 npm run build 所需的开发环境。

二、目标电脑导入

先把当前 optimize_ccc 源码通过 Git 或其它离线方式同步到目标机。
将本 ZIP 解压到独立目录，例如 D:\ECRA-cache-delta；不要解压覆盖旧缓存。
以下以源码位于 D:\global_static_concurrency_design 为例，在 Windows PowerShell 中执行：

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File D:\ECRA-cache-delta\Import-OfflineBuildDelta.ps1 -RepoRoot D:\global_static_concurrency_design -VerifyOnly

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File D:\ECRA-cache-delta\Import-OfflineBuildDelta.ps1 -RepoRoot D:\global_static_concurrency_design

导入脚本先校验所有 payload 文件和目标端同名文件；同名同内容跳过、不同内容则停止。
只复制缺少的文件，不覆盖旧缓存。脚本还核对当前源码的依赖声明及工具版本合同。
MANIFEST.json 为逐文件大小与 SHA256 清单。

三、纯离线检查及打包

在目标源码根目录打开 Windows PowerShell：

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\prepare_portable_cache.ps1 -OfflineCheck

必须看到 Verified Portable cache ready 且退出码为 0，再运行：

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build_portable.ps1 -OutputDir .\dist-offline-ccc -GitSource .\.tools-cache\git-diff-runtime\MinGit-2.56.0.3

dist-offline-ccc 应是尚不存在的新输出目录，脚本会保护已有包和配置。
不要在断网电脑运行不带 -OfflineCheck 的准备命令；build_portable.ps1 本身只使用本地资源。
studio-wheels.json 会由离线检查自动重新生成，无需从原电脑复制旧诊断文件。

若希望 VERSION.txt 记录当前 Git 提交，且目标机未安装 Git，可在当前 PowerShell 临时执行：

  $env:PATH = (Join-Path $PWD '.tools-cache\git-diff-runtime\MinGit-2.56.0.3\cmd') + ';' + $env:PATH

再打包即可。这不会更改系统 PATH；缺少系统 Git 也不妨碍打包，但可能无法记录源码提交。

四、如果目标机没有完整旧缓存

本增量不能替代基础环境。请额外迁移以下完整目录，保留每个 .portable-receipt.json：
  .tools-cache/python-3.10.9/
  .tools-cache/cmake-3.29.6/
  .tools-cache/ninja-1.13.2/
  .tools-cache/mingw-14.2.0-x86_64-mcf-seh-rev0/
  .tools-cache/arm-gcc-10.3-2021.10/
  .tools-cache/vc-runtime-14.44.35211.0/
另带：
  .tools-cache/downloads/pip-25.2-py3-none-any.whl 及 .receipt.json
  .tools-cache/downloads/ninja-1.13.2-COPYING.txt 及 .receipt.json
  .tools-cache/wheels/libclang-18.1.1-py2.py3-none-win_amd64.whl 及 .receipt.json
  .tools-cache/wheels/pyyaml-6.0.3-cp310-cp310-win_amd64.whl 及 .receipt.json

这些已解压且带收据的缓存能避开目标机对 7-Zip 的需求；不要只带 downloads/。
无需迁移 .tools-cache 中的研发日志、旧 cp312 wheel、测试工程、优化候选或历史验证结果。
也无需迁移 workspace、output、dist、客户数据和本机 Python/npm 缓存。

五、校验范围

本增量从本机已用于 V9 正式离线构建的同一份缓存选取。
新包的本次实际校验见同目录 VALIDATION.json；它不等于已在另一台物理机完成打包。

﻿param(
    [Parameter(Mandatory = $true)][string]$RepoRoot,
    [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repo = (Resolve-Path -LiteralPath $RepoRoot).Path.TrimEnd('\', '/')
$payload = Join-Path $PSScriptRoot 'payload'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Resolve-Child([string]$Parent, [string]$Relative) {
    if ([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|[/\\])\.\.([/\\]|$)') {
        throw "Unsafe relative path: $Relative"
    }
    $prefix = [IO.Path]::GetFullPath($Parent).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath((Join-Path $Parent $Relative))
    if (-not $full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Path escapes root: $Relative" }
    return $full
}

function Assert-NoLinkedParent([string]$Root, [string]$Path) {
    $cursor = $Path
    while ($cursor.Length -gt $Root.Length) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Linked destination requires manual review: $cursor"
            }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
    }
}

function Get-NormalizedTextSha256([string]$Path) {
    $body = [IO.File]::ReadAllText($Path).Replace("`r`n", "`n").Replace("`r", "`n")
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash([Text.Encoding]::UTF8.GetBytes($body))).Replace('-', '') }
    finally { $algorithm.Dispose() }
}

foreach ($requirement in $manifest.source_requirements) {
    $source = Resolve-Child $repo $requirement.path
    if (-not (Test-Path -LiteralPath $source -PathType Leaf) -or
        (Get-NormalizedTextSha256 $source) -ine $requirement.sha256) {
        throw "Checkout/cache contract differs: $($requirement.path). Use the current optimize_ccc source."
    }
}
foreach ($asset in @('build_portable.ps1', 'prepare_portable_cache.ps1', 'ecra/studio/web/index.html',
        'ecra/studio/web/licenses/inventory.json', 'ecra/studio/sample_assets/sample.json',
        'ecra/studio/sample_assets/stm32-demo.ecra-report')) {
    if (-not (Test-Path -LiteralPath (Resolve-Child $repo $asset) -PathType Leaf)) {
        throw "Required packaging source is missing: $asset"
    }
}

$pending = @()
$seen = @{}
foreach ($entry in $manifest.files) {
    if (-not $entry.path.StartsWith('.tools-cache/', [StringComparison]::Ordinal) -or $seen.ContainsKey($entry.path)) {
        throw "Invalid or duplicate payload path: $($entry.path)"
    }
    $seen[$entry.path] = $true
    $source = Resolve-Child $payload $entry.path
    if (-not (Test-Path -LiteralPath $source -PathType Leaf) -or
        (Get-Item -LiteralPath $source).Length -ne $entry.bytes -or
        (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ine $entry.sha256) {
        throw "Payload is missing or changed: $($entry.path)"
    }
    $target = Resolve-Child $repo $entry.path
    Assert-NoLinkedParent $repo $target
    if (Test-Path -LiteralPath $target) {
        if (-not (Test-Path -LiteralPath $target -PathType Leaf) -or
            (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ine $entry.sha256) {
            throw "Existing destination differs; nothing has been imported: $target"
        }
    } else {
        $pending += [PSCustomObject]@{source=$source; target=$target; sha256=$entry.sha256}
    }
}

Write-Host "Verified $($manifest.files.Count) payload files; $($pending.Count) files are missing from the destination."
if ($VerifyOnly) { Write-Host 'Verification only; destination unchanged.'; exit 0 }
foreach ($item in $pending) {
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($item.target)) -Force | Out-Null
    # Copy without overwriting a file created since the preflight check.
    [IO.File]::Copy($item.source, $item.target, $false)
    if ((Get-FileHash -LiteralPath $item.target -Algorithm SHA256).Hash -ine $item.sha256) {
        throw "Copied file failed verification; preserve imported files for inspection: $($item.target)"
    }
}
Write-Host 'Delta imported. Now run prepare_portable_cache.ps1 -OfflineCheck against the complete cache.'

# 全局变量与 static 变量完整清单

清单覆盖全局变量、文件 static、函数 static（含头文件实例和 C++ 静态成员）及补充声明；普通局部变量、参数和结构体字段不作为共享对象盘点。完整性受报告覆盖门槛约束。

| 变量 | 类别 | 定义 | 读上下文 | 写上下文 | 静态分类 / 覆盖率 | 最终分类 |
|---|---|---|---|---|---|---|
| g_value | GLOBAL | safe_same_context.c:2 | IRQ_LOW | IRQ_LOW | SAFE_PROVEN / COMPLETE | 已排查：未发现并发风险 |

## g_value

- ID: `c:@g_value`
- 类型: `volatile uint32_t`；大小: 4；对齐: 4
- const: False；volatile: True；翻译单元: safe_same_context.c

- 静态分类：SAFE_PROVEN；依据：静态已判安全：仅同一物理中断串行访问
- 最终分类：已排查：未发现并发风险
- 分析覆盖率：COMPLETE；缺口：无
- 保护：NOT_FOUND；说明：未发现关联路径上的同步或中断屏蔽操作。
- 安全筛除依据：SAFE_SINGLE_IRQ；阻塞项：无
- 不可达函数中的访问：0 处（保留原始证据）
- WRITE safe_same_context.c:3 `void SetValue(uint32_t value) { g_value = value; }`
  - IRQ_LOW: LOW_IRQHandler (safe_same_context.c:4) → SetValue (safe_same_context.c:3)
- READ safe_same_context.c:4 `void LOW_IRQHandler(void) { SetValue(g_value); SetValue(200U); }`
  - IRQ_LOW: LOW_IRQHandler (safe_same_context.c:4)
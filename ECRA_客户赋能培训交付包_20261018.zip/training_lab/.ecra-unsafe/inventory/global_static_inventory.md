# 全局变量与 static 变量完整清单

清单覆盖全局变量、文件 static、函数 static（含头文件实例和 C++ 静态成员）及补充声明；普通局部变量、参数和结构体字段不作为共享对象盘点。完整性受报告覆盖门槛约束。

| 变量 | 类别 | 定义 | 读上下文 | 写上下文 | 静态分类 / 覆盖率 | 最终分类 |
|---|---|---|---|---|---|---|
| g_value | GLOBAL | unsafe_direct_writeback.c:2 | IRQ_LOW | IRQ_HIGH, IRQ_LOW | SUSPECT / COMPLETE | 疑似并发风险 |

## g_value

- ID: `c:@g_value`
- 类型: `volatile uint32_t`；大小: 4；对齐: 4
- const: False；volatile: True；翻译单元: unsafe_direct_writeback.c

- 静态分类：SUSPECT；依据：存在已知跨物理上下文修改冲突；尚未证明不能交错或受到完整有效保护。
- 最终分类：疑似并发风险
- 分析覆盖率：COMPLETE；缺口：无
- 保护：NOT_FOUND；说明：未发现关联路径上的同步或中断屏蔽操作。
- 安全筛除依据：尚未证明；阻塞项：无
- 不可达函数中的访问：0 处（保留原始证据）
- WRITE unsafe_direct_writeback.c:6 `    g_value = value;`
  - IRQ_LOW: LOW_IRQHandler (unsafe_direct_writeback.c:8) → SetValue (unsafe_direct_writeback.c:3)
  - IRQ_HIGH: HIGH_IRQHandler (unsafe_direct_writeback.c:9) → SetValue (unsafe_direct_writeback.c:3)
- READ unsafe_direct_writeback.c:8 `void LOW_IRQHandler(void) { SetValue(g_value); }`
  - IRQ_LOW: LOW_IRQHandler (unsafe_direct_writeback.c:8)
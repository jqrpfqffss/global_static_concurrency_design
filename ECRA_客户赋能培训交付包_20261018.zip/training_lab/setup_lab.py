"""Refresh absolute compilation paths after moving this folder."""
import json
from pathlib import Path
root = Path(__file__).resolve().parent
for mode in ('unsafe', 'safe', 'serial'):
    path = root / ('compile_commands_' + mode + '.json')
    data = json.loads(path.read_text(encoding='utf-8'))
    for entry in data:
        entry['directory'] = str(root)
    path.write_text(json.dumps(data, indent=2), encoding='utf-8')
print('READY:', root)

# 全局变量与 static 变量完整清单

清单覆盖全局变量、文件 static、函数 static（含头文件实例和 C++ 静态成员）及补充声明；普通局部变量、参数和结构体字段不作为共享对象盘点。完整性受报告覆盖门槛约束。

| 变量 | 类别 | 定义 | 读上下文 | 写上下文 | 静态分类 / 覆盖率 | 最终分类 |
|---|---|---|---|---|---|---|
| g_value | GLOBAL | safe_irq_protected.c:2 | IRQ_LOW | IRQ_HIGH, IRQ_LOW | SUSPECT / COMPLETE | 疑似并发风险 |

## g_value

- ID: `c:@g_value`
- 类型: `volatile uint32_t`；大小: 4；对齐: 4
- const: False；volatile: True；翻译单元: safe_irq_protected.c

- 静态分类：SUSPECT；依据：存在已知跨物理上下文修改冲突；尚未证明不能交错或受到完整有效保护。
- 最终分类：疑似并发风险
- 分析覆盖率：COMPLETE；缺口：无
- 保护：PARTIAL；说明：检测到屏蔽操作，但未持续覆盖完整 READ→MODIFY→WRITE 窗口。
- 安全筛除依据：尚未证明；阻塞项：无
- 不可达函数中的访问：0 处（保留原始证据）
- WRITE safe_irq_protected.c:3 `void SetValue(uint32_t value) { g_value = value; }`
  - IRQ_LOW: LOW_IRQHandler (safe_irq_protected.c:4) → SetValue (safe_irq_protected.c:3)
  - IRQ_HIGH: HIGH_IRQHandler (safe_irq_protected.c:10) → SetValue (safe_irq_protected.c:3)
- READ safe_irq_protected.c:7 `    SetValue(g_value);`
  - IRQ_LOW: LOW_IRQHandler (safe_irq_protected.c:4)
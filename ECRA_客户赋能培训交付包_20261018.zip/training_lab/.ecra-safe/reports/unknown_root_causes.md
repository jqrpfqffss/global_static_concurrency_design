# 变量相关 UNKNOWN 根因

UNKNOWN 比例：0.0%；诊断阈值 10% 仅触发分析，不改变判定标准。

| 原因 | 变量数 |
|---|---:|

## 阻塞项传播

| blocker | 位置 | fanout | 诊断 |
|---|---|---:|---|

完整变量、源码位置和相关性解释保存在 facts.json 的 variable_evidence_slice / blocking_evidence。
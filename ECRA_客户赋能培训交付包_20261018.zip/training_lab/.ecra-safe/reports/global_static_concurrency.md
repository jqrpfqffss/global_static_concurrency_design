# 全局变量与 static 变量并发排查报告

## 与 HTML 一致的变量风险结论

| 已确认风险 | 疑似并发风险 | 无法判断 | 已复核安全 / 误报 | 已排查不存在并发风险 | 未发现静态线索 | 补充声明 |
|---|---|---|---|---|---|---|
| 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |

以上按 1 个变量去重；另有 0 项覆盖 / 依赖缺口。
risk_summary 是风险分类；review_summary 是模型复核进度，二者不能相互替代。“已排查不存在并发风险”仅适用于无盲区且没有读写冲突的当前建模范围。

- RR_build：1/1 = 100.0%（当前构建变量）
- RR_all：1/1 = 100.0%（含 0 个未分析的补充盘点声明）

- 静态归账：TOTAL 1 = SAFE_PROVEN 0 + SHARED_NO_REVIEW 0 + SUSPECT 1 + UNKNOWN 0

- 分析状态：**MODELED_SCOPE_COMPLETE**
- 本轮状态：**INCOMPLETE**
- 变量：1；候选及盲区复核项：1
- 编译单元：完整 1；部分 0；失败 0；可分析覆盖 100.0%（总计 1）
- 函数上下文覆盖：100.0%；未知访问：0
- 工程版本：b2ab3385441c82b5ea619b1940c5bff0b371ed7f；源码指纹：5f9d8f72ba2c5b58545e002a66c3f24e75714dadf5278b979028e18f7fd8accd

本报告是风险候选和覆盖证据，不是全工程无风险证明。OpenCode 结论仍需工程/硬件验证。

[变量完整清单](../inventory/global_static_inventory.md) · [未知项](unknown_contexts.md) · [OpenCode 复核](opencode_global_static_review.md)

- 本次仅排查配置目录中定义的变量（排除目录优先）；范围外变量不作安全结论。依赖仍用于恢复目标变量的访问与调用链。
- 并发访问证据只来自当前编译配置；其他条件分支通过变体补充声明盘点，不作为实际构建访问。
- 调用证据保留全部入口、调用边和递归边；小图列出全部无环路径，大图只展示标记为见证的最短路径。图证据及安全证明均不截断；显式 max_call_paths 超限仍失败。
- 保护事件 DETECTED 不等于 EFFECTIVE；只有 CFG 全路径和竞争者模型均完整才可排除冲突。Ownership 与屏障本身不等于互斥。
- 指针与回调采用跨函数、字段及常量数组元素区分的保守目标集合；动态下标仅与同数组可能重叠元素合并。DMA 方向来自 HAL API 契约；生命周期和 Cache 协议仍须复核。
- 清单只包含全局变量、文件 static 和函数 static（含头文件实例与 C++ 静态成员）；普通局部变量、参数和结构体字段不作为共享对象盘点，但指针/别名指向它们的共享访问仍按目标对象分析。
- 补充声明不等于已完成并发分析；无法恢复的类型、宏或条件组合会保留覆盖缺口，不能宣称完整或安全。

## 编译覆盖与排除

- unlisted_sources: 无
- unlisted_headers: 无
- excluded_sources: 无

## GS-7bbd6ced6855c2d0 — g_value

- 风险：HIGH；置信度：MEDIUM
- 静态分类：SUSPECT；本项分类：疑似并发风险（likely）
- 变量最终分类：疑似并发风险（likely）
- 规则：GS-MULTI-CONTEXT, GS-MULTI-WRITER
- 定义：safe_irq_protected.c:2；ID: `c:@g_value`
- 保护：PARTIAL；复核：PENDING / —
- 依据：基于物理执行上下文与存储重叠形成冲突；优先级或保护待确认不覆盖已知冲突

- **WRITE** safe_irq_protected.c:3 `void SetValue(uint32_t value) { g_value = value; }`
  - IRQ_LOW: LOW_IRQHandler (safe_irq_protected.c:4) → SetValue (safe_irq_protected.c:3)
  - IRQ_HIGH: HIGH_IRQHandler (safe_irq_protected.c:10) → SetValue (safe_irq_protected.c:3)
- **READ** safe_irq_protected.c:7 `    SetValue(g_value);`
  - IRQ_LOW: LOW_IRQHandler (safe_irq_protected.c:4)

复核动作：核对所有调用入口、真实抢占与临界区；构造最短交错时序，检查旧值覆盖、事件丢失、重入和 DMA 生命周期。修复建议与验证方法见复核报告。
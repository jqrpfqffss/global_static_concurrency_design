# 旧值写回培训实验

本目录复制了仓库 `tests/fixtures/stale_writeback` 的真实 fixture，保留原始 C 逻辑。它是用于解释分析流程的受控工程，不是可直接烧录的板级固件。无需 OpenCode 账户；静态扫描不产生模型调用。

将本目录复制到 ECRA 工具源码根目录，使用 PowerShell：

```powershell
$lab = (Resolve-Path '.\training_lab').Path
py -3.10 "$lab\setup_lab.py"
$cfg = Join-Path $lab 'semantics_unsafe.yaml'
py -3.10 run_ecra.py doctor --config $cfg
py -3.10 run_ecra.py --config $cfg --no-review
$scanExit = $LASTEXITCODE
Start-Process "$lab\.ecra-unsafe\index.html"
```

迁移目录后必须重新执行 `setup_lab.py`。它只更新三个编译数据库中的绝对 `directory`，不修改工具侧活动配置。配置使用 `root: .`，相对本 YAML 所在目录。

| 变体 | 配置 | 本次实际结果 |
|---|---|---|
| 两个 IRQ 旧值写回 | semantics_unsafe.yaml | 1 变量、1 候选；SUSPECT + COMPLETE；NOT_FOUND；PENDING；exit 2 |
| LOW 读取及写回包在屏蔽中 | semantics_safe.yaml | 1 变量、1 候选；SUSPECT；PARTIAL；PENDING；exit 2 |
| 只有同一个 IRQ 访问 | semantics_serial.yaml | 1 变量、0 候选；SAFE_PROVEN / SAFE_SINGLE_IRQ；exit 0 |

对照执行：

```powershell
py -3.10 run_ecra.py --config (Join-Path $lab 'semantics_safe.yaml') --no-review
py -3.10 run_ecra.py --config (Join-Path $lab 'semantics_serial.yaml') --no-review
Start-Process "$lab\.ecra-safe\index.html"
Start-Process "$lab\.ecra-serial\index.html"
```

`safe_irq_protected.c` 增加屏蔽后仍保留候选是实际工具结果：当前自动保护证明没有为该 ISR 间路径给出完整安全结论，不能把“检测到保护”解释为“已自动证明安全”。生产代码的通用修复应核对屏蔽范围并保存/恢复原中断状态，不能无条件照搬本受控 fixture 的 `__enable_irq()`。

可选宿主机回放需要本机 gcc，命令从工具根目录运行：

```powershell
gcc -std=c11 .\training_lab\replay.c -o .\training_lab\replay.exe
.\training_lab\replay.exe
```

预期：`READ 100 -> HIGH WRITE 200 -> LOW WRITEBACK 100; final=100`。这个程序在 Setter 入口注入一次确定的 HIGH 调用，核验指定交错。它不模拟 STM32 外设、DMA、总线或物理时间，也不是目标板复现。

每个配置对应一份独立编译数据库，只选一个真实 C 源文件。`fixture.h` 自带 32 位类型声明，所以此实验设置 `auto_system_includes: false`；真实固件通常应设为 `true` 并采用真实构建参数。

教学源码、YAML 和辅助脚本均可编辑。已有 `.ecra-*` 为本次本机扫描产物；迁移后重跑可生成当前路径的结果。请勿将这些 fixture 的编译参数直接用于客户真实固件。

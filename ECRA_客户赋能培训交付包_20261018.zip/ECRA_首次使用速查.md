# ECRA 首次使用速查

适用：Windows PowerShell、ECRA 当前源码、Python 3.10+。把本交付中的整个 `training_lab` 复制到 ECRA 工具根目录，先用受控案例熟悉操作。无需模型账户，不烧录目标板。

```powershell
# 进入实际 ECRA 源码目录，下面为客户部署路径示例
Set-Location 'D:\ECRA'
py -3.10 -m pip install -r requirements.txt
py -3.10 run_ecra.py --help

$lab = (Resolve-Path '.\training_lab').Path
py -3.10 "$lab\setup_lab.py"
$cfg = Join-Path $lab 'semantics_unsafe.yaml'
py -3.10 run_ecra.py doctor --config $cfg
py -3.10 run_ecra.py --config $cfg --no-review
$scanExit = $LASTEXITCODE
Start-Process "$lab\.ecra-unsafe\index.html"
```

预期：`setup` 显示 `READY`，`doctor` 通过，扫描得到 **1 个变量、1 个候选**。`g_value` 是 `SUSPECT + COMPLETE`，保护 `NOT_FOUND`，复核 `PENDING`。`run.json` 的 `exit_code: 2` 表示本例复核未完成；本例编译单元已完整解析。先检查范围和覆盖，再展开变量访问与调用链，核对两个 IRQ 的读取和写回窗口。

| 返回码 | 判断与动作 |
|---|---|
| 0 | 环境检查成功，或扫描覆盖门槛通过且没有候选 |
| 1 | 流程完成但仍有候选记录，打开报告查看结论 |
| 2 | 覆盖或复核不完整，查看缺失事实与待办 |
| 3 / 130 | 致命失败 / 用户中断，查看日志后修复或继续 |

接入客户固件：编辑工具侧 `config/semantics.yaml`，填写 `project.root`、自有代码包含/排除目录和真实 CMake 参数或编译数据库。`project.root` 相对 YAML，其余工程路径一般相对固件根。首次保持 `review.enabled: false`。以绝对配置路径执行相同的 `doctor` / `run`，报告默认在固件 `.ecra/index.html`。

排障入口：配置错误看 YAML/绝对路径；构建错误看 `cmake-configure.log` / `cmake-build.log`；解析与空结果看“过滤与覆盖校验”和 `reports/unknown_contexts.md`；旧检查点先完整重扫。仅刷新页面用 `report`。启用可选模型后，全部候选重评用 `review`，仅技术失败用 `review-failed`。

便携版：用包内 `.\runtime\python.exe` 替代 `py -3.10`，用 `.\ecra.cmd` 替代 `py -3.10 run_ecra.py`。仓库已有便携包构建于 2026-10-16，交付当前源码需重建并自检。目标板行为、其他操作系统和客户具体工程兼容性待验证。详见 PPT 第 24–49 页。

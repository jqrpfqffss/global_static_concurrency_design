# ECRA 客户技术赋能培训：逐页讲解备注

对应 49 页正式 PPTX。相同讲解内容已写入每页 PowerPoint 演讲者备注。

主讲路径：背景 1–10；原理 11–23；使用教程 24–49。建议 90–120 分钟，按客户基础调整。

## 第 01 页　让并发问题有据可查，让客户能够独立排查

开场说明：本课帮助客户独立完成配置、扫描、报告分析和异常处理。ECRA 面向 STM32 固件的共享存储问题。今天先讲为什么需要，再讲如何工作，最后现场跑通一个旧值写回案例。文中“候选”是静态分析线索，不能直接等同于板上已复现缺陷。

项目依据：README.md；pyproject.toml

## 第 02 页　学完后，客户能够完成一次排查闭环

建议课程安排约 90–120 分钟，按现场基础调整，其中至少一半时间留给使用演示和练习。讲师先展示第 49 页速查，让学员知道最终要掌握的操作。完成标准是学员能够说明变量由谁访问、候选为何成立、还缺什么证据，以及下一步如何验证。时长是培训安排建议，不是工具耗时承诺。

项目依据：docs/one-command-tutorial.md；docs/variable-investigation-guide.md

## 第 03 页　偶发错误常常来自两个执行者之间的插入

把问题落在日常调试体验上。源码中的一条表达式可能包含多步读写，而中断可以插入步骤之间。本仓库的受控用例覆盖旧快照写回、跨字段不一致和 DMA 缓冲区复用等机制。这里列的是这些机制可能表现出的现象，不声称客户已经发生这些故障。

项目依据：tests/fixtures/stale_writeback/unsafe_direct_writeback.c；tests/fixtures/stm32_cdc/README.md

## 第 04 页　同一个 Setter 也可能把新值覆盖成旧值

贯穿案例来自 unsafe_direct_writeback.c。LOW 调用 SetValue(g_value)，函数实参在进入 Setter 前就已读取。高优先级 IRQ 随后写 200，LOW 恢复后将之前保存的 100 写回。100 的初值来自受控 replay，不是固件中固定的初值。宿主机回放以明确抢占点验证这一交错，不代表已做 STM32 板上复现。

项目依据：tests/fixtures/stale_writeback/unsafe_direct_writeback.c:2；tests/fixtures/stale_writeback/replay.c

## 第 05 页　传统排查缺少一份可追溯的共享访问地图

强调互补关系。全文搜索和运行测试都有价值，ECRA 把变量和执行关系整理成统一证据。工具可以给测试设计提供线索，运行验证则检查这些线索是否满足实际触发条件。没有项目测量数据，因此不承诺提升百分比、节省工时或普遍准确率。

项目依据：README.md；ecra/extract.py；ecra/analysis.py

## 第 06 页　错误的共享访问会破坏更新、快照或缓冲区所有权

逐行只讲机制对应的影响。不要把源码支持的局部错误升级成未经证实的系统事故。比如 DMA 用例的直接问题是源缓冲区生命周期，是否丢帧、发错命令需结合客户协议确认。使用这些候选来决定后续板上或单元测试应观察什么。

项目依据：tests/fixtures/stm32_cdc/p01.c；tests/fixtures/stm32_cdc/p05.c；tests/fixtures/stm32_cdc/p10.c；tests/fixtures/stm32_cdc/p11.c；tests/fixtures/stm32_cdc/p12.c

## 第 07 页　ECRA 把共享对象、执行关系和证据放进同一报告

项目定位是一款共享存储并发排查工具。客户无需逐个登记变量。扫描不修改固件源码，CMake 模式可以配置和构建工程并写入指定构建目录。OpenCode 是工具可选功能，本次制课没有发起真实模型调用；当前会话按直接执行模式工作。

项目依据：README.md；ecra/cli.py:95；ecra/compilation.py:12

## 第 08 页　排查对象由当前构建和变量定义位置共同决定

范围由两个条件共同约束：当前构建中的代码，以及 include/exclude 指定的定义位置。结构体与数组存在容器和子对象，统计采用 canonical 对象，父容器不会重复计入分类分母。局部变量和参数仍可参与别名与传播分析，不会逐个当作共享变量清单列出。

项目依据：README.md#完整变量清单与覆盖检查；ecra/scope.py；ecra/target_set.py；ecra/storage.py

## 第 09 页　使用前后的具体变化是证据可见、范围可查

本页只陈述可从产物核验的改善，不把它转成未经测量的效率指标。演示如何从变量行定位访问点，再定位原始源码。保存报告与输入指纹使团队有共同的讨论依据，但一致的证据归档不能保证推理或硬件行为一定正确。

项目依据：ecra/html_report.py；ecra/report.py；ecra/workflow.py；ecra/review_integrity.py

## 第 10 页　本课用真实测试和可复现练习建立使用依据

本次在当前工作区实际执行 py -3.10 -X utf8 -m unittest discover -s tests -q，运行 663 项、跳过 2 项，其余通过。另执行 replay_stm32_interleavings.py，14 个预设交错检查通过。两种验证用途不同：测试验证实现和协议，回放检查指定调度模型。均不代表真实板上验证或通用检测准确率。

项目依据：tests/；scripts/replay_stm32_interleavings.py；.codex/customer_enablement_20261018/replays/results.json

## 第 11 页　工具先恢复事实，再判候选，最后生成可读报告

按整体流程先建立认知。现有编译数据库模式直接进入事实提取，CMake 模式先刷新编译输入。静态分类发生在模型之前，SAFE_PROVEN 和 SHARED_NO_REVIEW 默认不进入普通复核队列。模型复核完成后再次生成报告，不逆向篡改原始静态分类。覆盖缺口贯穿流程，始终作为限制保留。

项目依据：ecra/cli.py:95；ecra/analysis.py；ecra/evidence.py:426；ecra/report.py

## 第 12 页　分层结构让构建事实、风险判断和展示各司其职

架构图按客户能理解的职责组织。事实提取依赖真实编译参数，分析层组合事实，展示层将结果变成报告。最后一层横跨分析结果与复核输出，是消费者而不是额外源码入口。具体实现可在 cli、compilation、extract、points_to、physical、protection、evidence、review 和 report 中追溯。

项目依据：ecra/cli.py；ecra/compilation.py；ecra/extract.py；ecra/points_to.py；ecra/report.py

## 第 13 页　真实编译参数决定工具究竟看到了哪一份固件

解释编译数据库的重要性：同一文件在不同宏下可能是不同程序。工具会保留原始参数并转换为 Clang 可用输入，自动探测 Arm GCC 标准头文件路径。expected_defines 只检查已有宏，不会替客户注入宏。build_closure_only 默认 true，未纳入构建的模块不能被声称已完成并发分类。

项目依据：ecra/compilation.py；ecra/config.py；README.md#准确性边界

## 第 14 页　变量身份来自实际存储，名字相同也可能是两个对象

用“两个部门各有一本名叫 count 的账本”解释同名 static。只有同一实际存储的访问才构成该变量的冲突。指针、union、位域及字节级访问可能使重叠关系更复杂，工具以恢复到的证据判断，无法确定时保留缺口。

项目依据：ecra/extract.py；ecra/storage.py；ecra/target_set.py；tests/test_complete_inventory.py

## 第 15 页　是否并发取决于执行者，函数名字不能决定上下文

函数叫 Task 不等于 RTOS 任务，主循环同步调用的协作任务仍继承前台。来自同一个物理 IRQ 的不同回调路径不会凭空成为两个相互并发的中断。工具会恢复标准 IRQ、任务注册及部分回调；配置用于补充实际入口。无法恢复的异步触发者会成为未知上下文。

项目依据：ecra/physical.py:8；ecra/async_semantics.py；examples/stm32_demo/semantics.yaml

## 第 16 页　沿着指针和调用链才能找到间接写入

这是对仓库支持机制的通俗概括，图中包装函数为说明性抽象，不冒充逐字源码。实际实现支持跨翻译单元参数、返回值、结构成员指针、内存函数包装和部分函数指针。目标集合通常是保守集合，可能包含多个目标；缺失的间接边或无法恢复的别名都需要在报告中继续审查。

项目依据：ecra/pointer_extract.py；ecra/points_to.py；ecra/context_points.py；tests/test_points_to.py

## 第 17 页　同一存储存在可能交错的修改，才形成冲突线索

让客户把判断拆成四个问题。对于已知冲突，未恢复优先级或保护细节不应把风险线索抹掉，可能呈现 SUSPECT + PARTIAL。不存在已知冲突但相关证据可能隐藏冲突时呈现 UNKNOWN。严格单写者只读观察还可能满足 SHARED_NO_REVIEW 门禁，下一页继续解释。

项目依据：ecra/evidence.py:426；ecra/analysis.py；ecra/interrupts.py

## 第 18 页　旧值写回分析必须覆盖读取到最终写入的整个窗口

旧值可能经参数、返回值、多层包装或对象快照传播。只在 Setter 内关中断时，参数里的旧值已经生成，保护来得太晚。完整窗口的安全前提还包括竞争方确实被屏蔽、没有 DMA 或不可屏蔽中断干扰。对嵌套场景应保存并恢复原 PRIMASK，而不是通用地无条件 enable。本页是 p03/p13 实际源码的机制对照，静态工具是否能自动证明应以输出为准。

项目依据：ecra/stale_writeback.py；tests/fixtures/stm32_cdc/p03.c；tests/fixtures/stm32_cdc/p13.c

## 第 19 页　保护有效性由完整路径和竞争方共同决定

当前保护分析使用控制流与状态传播检查分支、汇合、调用和整个窗口。报告的六态为 NOT_FOUND、DETECTED、PARTIAL、EFFECTIVE、UNRESOLVED、INEFFECTIVE。不要把检测到保护当作有效保护。当前自动有效性证明仍有边界，尤其是复杂 ISR 间关系、DMA/cache 与不支持的控制流。

项目依据：ecra/protection.py:304；ecra/controlflow.py；ecra/interrupts.py；tests/test_effective_decisions.py

## 第 20 页　当前版本使用四种静态分类，覆盖状态另行保存

按当前 evidence.py 和报告四分类讲解，部分旧文档仍写三分类。四类按 canonical 变量归账，OUT_OF_BUILD 补充声明独立处理。COMPLETE/PARTIAL 是访问与推断覆盖状态，与风险分类不是同一维度。SUSPECT + COMPLETE 表示线索完整仍需判断业务与可行交错，SUSPECT + PARTIAL 表示已有冲突并伴随缺失事实。共享免复核不代表任何单 writer 都安全，涉及读改写、协议或未知目标时会被门禁拒绝。

项目依据：ecra/evidence.py:312；ecra/evidence.py:426；ecra/report.py:168；ecra/html_report.py:27

## 第 21 页　复核把变量证据变成解释，再校验并归档结果

可选模型使用现有 OpenCode 配置及提供商。review_context.md 是待源码核实的项目声明，concurrency_cases.md 提供案例索引和只读正文。相似案例不直接证明风险。合法语义结论五种都可以 DONE，技术执行失败则 TECH_FAILED。格式异常最多两次轻量 FORMAT_FIX。旧值写回的安全/误报答案还需要专门的窗口阻断说明，不能只说 store 原子。收据校验保证归档一致性，不证明推理正确。

项目依据：ecra/review.py；ecra/review_contract.py；ecra/review_integrity.py；ecra/case_library.py

## 第 22 页　静态证据能指导验证，最终结论仍受建模条件约束

既不降低工具价值，也不承诺全工程无竞态。没有解析错误不等于所有硬件行为都建模完成，静态安全也只适用于列出的证据和前提。真实板上复现、未测试的操作系统和新客户工程的兼容性均为待验证。对未知项列清具体缺失信息，比用一个“安全”结论掩盖盲区更有帮助。

项目依据：README.md#准确性边界；docs/portability-validation.md；ecra/multicore.py

## 第 23 页　历史矩阵暴露过误报，最终四项定向复测不能外推

数据来自 2026-10-18 仓库已有 STM32CubeF4 CDC 验证记录。首轮 13/13 风险、4/5 安全对照、1/2 证据不足，共18/20状态符合。后来 p16、p17、p18、p19 四项定向复测均符合，但不构成最终版本重新跑完的全矩阵。后续重复验证因提供商余额不足中止，原生 UserTxBufPtrIn 的最终复核仍未完成。本次培训制作未调用该提供商。这些是受控样本，不能当作通用准确率或硬件安全认证。

项目依据：docs/stm32_cube_cdc_validation.md#二十项矩阵；docs/stm32_cube_cdc_validation_results.json

## 第 24 页　Windows 是本课已核验路径，源码运行要求 Python 3.10+

源码声明 Python >=3.10，依赖 libclang==18.1.1 和 PyYAML>=6.0.2,<7。便携版内置 Python 3.12.10、CMake、Ninja 和 Arm GCC，不依赖系统 Python。源码有跨平台机制，但本课仅在 Windows 实测，Linux/macOS 客户环境兼容性标记待验证。非 CMake 模式使用已有真实编译数据库；培训 fixture 不需要真实固件编译，但不能据此推断任意工程也不需要工具链。

项目依据：pyproject.toml；requirements.txt；config/portable_sources.psd1；README.md#Windows Full Portable 离线打包

## 第 25 页　便携部署只需解压并调用包内入口

D:\ECRA-Portable 是客户示例部署路径，按实际位置替换。交付文件为 dist/ECRA-Portable.zip，无公开下载地址可核实。当前已有包的 VERSION.txt 构建于2026-10-16，不能视为本次当前源码快照；当前版离线重建命令是 powershell -NoProfile -ExecutionPolicy Bypass -File .\build_portable.ps1，前提是完整 .tools-cache，先运行 prepare_portable_cache.ps1 -OfflineCheck。构建和解压自检均由脚本执行。本次未重新打包，当前快照的便携包须重建后验证。

项目依据：README.md#Windows Full Portable 离线打包；dist/ECRA-Portable/VERSION.txt；dist/ECRA-Portable/ecra.cmd；build_portable.ps1

## 第 26 页　源码部署先安装两个依赖，再确认入口可用

从项目交付方获取完整源码快照。依赖安装需要可用包源或匹配当前 Python/架构的离线 wheel。本课在已具备依赖的 Python3.10环境实测扫描，不声称在全新电脑上重新下载安装过。解析库检查命令应无异常且返回0，不会打印额外文字。pyproject.toml 定义 ecra 入口，pip install -e . 后可用简短命令。本页命令可从配套速查复制。不要在 Python3.10 上使用给便携 Python3.12 准备的专用 wheel。

项目依据：pyproject.toml；requirements.txt；run_ecra.py

## 第 27 页　唯一活动配置位于工具侧，固件目录保存运行产物

这是最容易填错的路径规则。正常使用工具侧唯一 config/semantics.yaml，不在每个固件 .ecra 下另放活动配置。--project 只临时覆盖固件根。显式 --config 建议传绝对路径：当前 resolve_config_path 将相对 --config 以活动配置目录为基准，而不是终端工作目录。工具目录不可写时，在启动前设置 ECRA_CONFIG_HOME 指向可写配置目录。init 不会覆盖已有配置；切换项目直接编辑当前文件。培训实验使用独立显式配置，避免覆盖客户活动项目。

项目依据：ecra/config.py；ecra/cli.py:370；README.md#裸机 CMake 工程：配置一次，日常一条命令

## 第 28 页　包含目录决定目标变量，依赖目录仍可提供调用证据

不要机械把所有 Drivers/BSP 都排除，客户自有代码可能就在这些目录。头文件 static 看不见时先检查定义目录和该头文件是否真正参与当前构建。补充声明模式 build_closure_only:false 会盘点 OUT_OF_BUILD 声明，但不会将其当作当前固件已分析安全。过滤报告应逐文件核对，零变量文件也需要看诊断。

项目依据：ecra/scope.py；ecra/compilation.py；ecra/supplemental.py；config/semantics.yaml

## 第 29 页　这份完整练习配置明确指定输入、范围和输出

本页与下一页共同给出一份完整、已实跑配置。原始 YAML 随 training_lab 交付，可直接用，不要拼接两页截图。auto_system_includes:false 仅因为这个小型 fixture 自带 uint32_t，不使用工具链标准头。真实 STM32 工程通常保持 true。parse_timeout_seconds 是每个翻译单元解析超时，output_dir 必须是固件根内独立子目录。chip/core 是说明字段，不能代替真实编译参数。

项目依据：output/customer_enablement_20261018/training_lab/semantics_unsafe.yaml；ecra/config.py

## 第 30 页　同一配置的后半部分补齐入口，并关闭首次模型调用

展示同一 YAML 的剩余字段，注意缩进使用空格，不能重复顶层 analysis 或 review。review.timeout_seconds 是每次模型调用的等待上限，retries 是额外技术重试次数；两次格式修复是另一条限制。max_items:1 依然会自动分批处理全部目标，不能用于限制总费用。客户首次接入保持模型关闭。

项目依据：ecra/config.py；ecra/review.py；output/customer_enablement_20261018/training_lab/semantics_unsafe.yaml

## 第 31 页　接入真实固件时，用项目已有构建参数替换练习数据库

本段来自项目 CMake 模板，属于客户接入示例，具体目录和工具链文件待客户工程验证。analysis.cmake 不能与另一位置的显式 compile_database 冲突。build_dir 使用独立 build/ecra，clean_before_configure:false 适合增量。若设 true，工具会删除且只删除此指定构建目录再配置，不能填 IDE 正在使用的产物目录。自定义注册可添加 entry_registrations，例如 api:BSP_RegisterAdcCallback、callback_arg:1、kind:ISR、context_id:adc_irq；必须先确认真实 API 参数和 IRQ 归属，不能伪造同步调用边。

项目依据：ecra/config.py#CMAKE_TEMPLATE；ecra/compilation.py:12；config/semantics.yaml

## 第 32 页　doctor 先检查分析输入，run 再生成本轮报告

路径 D:\MyFirmware 是客户接入示例，打开报告时替换为 project.root。doctor 在 CMake 模式会 configure 并验证数据库，不编译固件、不扫 AST，也不测试模型提供商连接。--no-review 对本次 run 覆盖 enabled:true。返回码0是无候选且覆盖门槛通过，1是流程完成但存在候选记录，2是覆盖或复核不完整，3是致命配置/运行失败，130是中断。本次风险练习的 run.json 明确 exit_code:2，因为 PENDING，不是解析失败。

项目依据：ecra/cli.py:95；ecra/cli.py:329；docs/one-command-tutorial.md

## 第 33 页　不同入口分别处理重新扫描、刷新页面和继续复核

命令统一写法是 py -3.10 run_ecra.py <命令> --config $cfg。review 即使上次 DONE 也重评当前全部疑似/未知；review-failed 只处理技术失败，包括成功后自动退出失败集合。status 不代表重新校验全部静态事实，report/review 的检查点一致性校验会拒绝过期输入。--model、--compile-database、--toolchain-file 仅用于 init，已有配置请编辑 YAML。

项目依据：ecra/cli.py:370；ecra/workflow.py；README.md#OpenCode 复核与持续使用

## 第 34 页　HTML 用于交互查看，机器可读产物用于留证和集成

默认输出为 project.root/.ecra，练习为 .ecra-unsafe 等独立目录。报告无需服务器即可双击打开，源码超链接依浏览器的本地访问策略可能需要从编辑器定位。cmake-configure.log 和 cmake-build.log 用于构建错误。input_manifest.json、scan_state.json 关联输入与实现，snapshots 保存上一轮。report 不会伪造新的扫描时间。

项目依据：ecra/report.py；ecra/html_report.py；ecra/cli.py；README.md#输出

## 第 35 页　先看总体状态和覆盖，再定位变量详情

本页为本次真实练习生成的 index.html 浏览器截图。先读报告结论及“模型复核未启用”，再核对源码解析完整1、部分0、失败0。不要把已确认风险为0读成没有风险。变量行显示 g_value 定义于 unsafe_direct_writeback.c:2，复核状态为待人工核对。点击详情后查看读写位置与LOW/HIGH入口。截图只作操作导航，数据分析以配套实际 HTML/JSON 为准。

项目依据：output/customer_enablement_20261018/training_lab/.ecra-unsafe/index.html

## 第 36 页　读一条变量记录时，把风险、覆盖和保护分开判断

报告存在多个维度。COMPLETE并不自动转成SAFE，表示当前分析证据覆盖达标。本例同一源码store在SetValue:6，关联IRQ_LOW与IRQ_HIGH两条调用链；读取在LOW:8。阅读源码位置、上下文与交错说明后，再判断哪些条件需要运行验证。保护完整六态详见第19页；可以在变量详情展开查看。

项目依据：output/customer_enablement_20261018/training_lab/.ecra-unsafe/facts.json；ecra/html_report.py

## 第 37 页　五种模型语义结论与技术执行状态分别决定下一步

所有五种合法语义结论都属于DONE，DONE只说明分析结束，不说明安全。LIKELY和NEED_MORE_CONTEXT必须列出具体missing_context。CONFIRMED、REVIEWED_SAFE、FALSE_POSITIVE要求有效源码证据。报告的reason、interleaving、protection、impact、evidence、fix、verification分别回答为什么、怎样交错、保护范围、影响、源码位置、修复与验证建议。verification是建议，不冒充已经测过。TECH_FAILED是独立技术状态，不应拿NEED_MORE_CONTEXT代替。

项目依据：ecra/review_contract.py:7；docs/opencode-review-format.md；ecra/review.py

## 第 38 页　练习先更新目录，再用独立配置扫描风险样本

练习目录随交付包提供，复制整个training_lab到ECRA源码根目录。setup_lab.py仅更新编译数据库中的绝对directory，迁移电脑后必跑，不覆盖中央配置。编译数据库描述ARM Cortex-M4 C11输入，小型fixture不依赖HAL库且不烧录。配置使用绝对路径避免--config相对路径误解。若使用便携版，把py -3.10替换为.\runtime\python.exe，把py -3.10 run_ecra.py替换为.\ecra.cmd；先按当前源码版本重建并自检便携包。

项目依据：output/customer_enablement_20261018/training_lab/setup_lab.py；tests/fixtures/stale_writeback/unsafe_direct_writeback.c

## 第 39 页　真实输出显示两个 IRQ 共用写点，并保留旧值写回候选

现场打开真实HTML和facts.json。让学员解释为什么一次store可以有两个入口，为什么静态候选尚不是已完成的模型结论。完整读取到写回路径由unsafe fixture和replay支持，本次静态扫描保留READ_THEN_WRITEBACK提示。让学员找到protection_status:NOT_FOUND，并说出下一步是补全保护/时序依据和设计验证。

项目依据：output/customer_enablement_20261018/training_lab/.ecra-unsafe/facts.json；output/customer_enablement_20261018/training_lab/.ecra-unsafe/review/queue.json

## 第 40 页　保护对照仍需人工核对，串行对照给出独立安全依据

三个文件均来自仓库原始fixture。safe_irq_protected在LOW中包住读取和写回，但当前自动保护评估没有为这一ISR间路径给出完整安全证明，仍保留SUSPECT/PARTIAL；不要为教材漂亮而改写结果。safe_same_context只有LOW访问，配置中也删除不存在的HIGH，得到SAFE_SINGLE_IRQ，run状态REVIEW_COMPLETE、exit0。运行命令为py -3.10 run_ecra.py --config (Join-Path $lab "semantics_safe.yaml") --no-review，serial同理。安全对照的语义与自动证明能力须分开讲。生产修复建议优先保存/恢复原屏蔽状态，原fixture是受控示例，不直接当通用生产补丁。

项目依据：tests/fixtures/stale_writeback/safe_irq_protected.c；tests/fixtures/stale_writeback/safe_same_context.c；ecra/protection.py:304

## 第 41 页　配置失败先检查 YAML 和路径解释规则

演示当前仓库不允许重复键，错误会含行号。init检测到配置存在时拒绝覆盖，这是保护已有工程设置；此时直接编辑project.root。project.root相对YAML，其他工程路径相对固件根，--config相对活动配置目录。输出和构建目录必须是工程内独立子目录，不能指向工程根或外部目录。不要通过关掉检查来掩盖错误。

项目依据：ecra/config.py:15；ecra/config.py#resolve_config_path；ecra/cli.py:95

## 第 42 页　构建失败应先恢复固件原本可用的构建方式

PowerShell核对命令：Get-Command cmake,ninja,arm-none-eabi-gcc；Resolve-Path .\cmake\实际文件.cmake。不要删除IDE构建目录。toolchain_file必须与真实工程一致，cmake.args每项是一个完整参数，不能放-S/-B/-G等由专用字段控制的参数。Ninja或Makefiles生成器才应期待compile_commands.json。doctor在此阶段失败时还没有完成源码分析。

项目依据：ecra/compilation.py:12；docs/one-command-tutorial.md#常见故障与处理

## 第 43 页　解析失败与清单为空，都要先核对构建覆盖

解析错误不应靠删除_Atomic或无视诊断解决。auto_system_includes通常保持true，让工具询问真实ArmGCC。expected_defines只检查不注入，需要修正CMake的实际宏。变量为空时核对定义文件归属、exclude_files、build_closure和头文件是否实际包含。同名static多行通常是不同实例，不是重复错误。parse_timeout_seconds是单个编译单元上限，只有确认输入正确且确实解析耗时长才增加。

项目依据：ecra/compilation.py；ecra/extract.py；ecra/scope.py；docs/one-command-tutorial.md

## 第 44 页　模型未完成时，先分清证据不足还是技术失败

只做本地扫描时PENDING是正常结果，不需要为了变绿而开启模型。合法NEED_MORE_CONTEXT是DONE，不会被review-failed重跑。若客户决定启用复核，编辑review.enabled:true，command:[opencode]，必要时model:provider/model，timeout/retries/workers按实际配置；然后py -3.10 run_ecra.py review --config $cfg。源码和证据将由客户配置的提供商处理，启用前按客户的数据政策确认。当前会话未进行模型调用。HTTP429余额问题在历史验证中实际发生，修复额度后再重试，不能把技术失败当安全。

项目依据：ecra/review.py；docs/review_failed_validation.md；docs/stm32_cube_cdc_validation.md

## 第 45 页　零候选、旧报告和遗留锁各有不同排查入口

零候选不能单独证明覆盖完整。本次串行对照初次保留不存在的HIGH上下文时，虽然变量静态安全仍出现UNMATCHED_CONTEXT，修正入口后才得到完整状态，这可作为现场说明。报告刷新不会替代重新提取事实。锁文件防止同目录并行写入，先Get-Content $out\scan.lock，Get-Process -Id <PID>核实；只有确认旧进程已结束才Remove-Item -LiteralPath该锁。不要盲删目录或强制替换输入指纹。

项目依据：ecra/cli.py:107；ecra/workflow.py；ecra/config.py

## 第 46 页　宿主机回放可以核验指定交错，但不模拟目标板

单案例回放将原unsafe_direct_writeback.c包含进驱动，在Setter入口注入HIGH，检查100变200再被写回100。矩阵回放直接在fixture副本插入一次性抢占点，不是重写一份等价算法。p11检查16次循环无推进的有界模型，不能说证明无限硬件死循环。修复后应对比静态候选和运行验证，必要时补反汇编与板上实验。gcc仅是这个可选练习的宿主机编译依赖，日常ECRA扫描不要求安装宿主gcc。

项目依据：tests/fixtures/stale_writeback/replay.c；scripts/replay_stm32_interleavings.py

## 第 47 页　日常复扫以输入变化为触发，并保留验证前提

把semantics.yaml、review_context.md与concurrency_cases.md作为受控配置维护，切换工程时同步更新。每个核、宏配置和Debug/Release分别扫描。baseline.no_longer_observed只表示本轮不再观察到，不能自动记作已修复。snapshots会增长，按团队保留策略管理。交付或提单时附工具版本、固件版本、构建变体、候选证据和验证结果，不把模型修复建议当作已实施修复。

项目依据：ecra/workflow.py；ecra/review_context.py；ecra/case_library.py；README.md#OpenCode 复核与持续使用

## 第 48 页　六种保护标记说明证据强弱，只有完整证明才有效

将本页作为看报告时的保护字段字典。NOT_FOUND并非证明绝无保护，而是当前关联路径没有恢复到保护操作。DETECTED只是直接事实。PARTIAL不能排除风险。EFFECTIVE必须结合竞争者和范围，不能推广到DMA、NMI或其他未建模变体。UNRESOLVED保留条件未明的状态。DMB/DSB/ISB仅有屏障操作时不能提供IRQ互斥，可表现为INEFFECTIVE。与静态分类、覆盖状态和模型复核状态分别阅读，不按单个绿色标签决定整个项目安全。

项目依据：ecra/protection.py:304；ecra/html_report.py

## 第 49 页　首次使用速查：部署、配置、扫描、读证据

让学员仅用本页完成首次练习。完整可复制命令也提供在首次使用速查.md和training_lab/README.md。第一次成功的标志是能打开报告并解释SUSPECT、COMPLETE、PENDING各自表示什么，不是要求退出码一定为0。转入客户固件时使用实际CMake或真实数据库，不复制fixture的编译参数。常见错误返回第41–45页。最后请学员说出：工具解决什么、如何工作、如何部署配置、如何运行、去哪看结果、遇错怎么查。

项目依据：docs/one-command-tutorial.md；output/customer_enablement_20261018/training_lab/semantics_unsafe.yaml
